/* Supabase connection — the URL and the "anon public" key are safe to publish.
   Data is protected by Row Level Security in the database. Never put the service_role key here. */
window.OFFRAVA_CONFIG = {
  SUPABASE_URL: 'https://xpnujwgkzlmwtxgvayeu.supabase.co',
  // Stripe PUBLISHABLE key (starts with pk_). Public by design. Never put the sk_ secret key here.
  STRIPE_PUBLISHABLE_KEY: 'pk_test_51UVJgsE053AcYOCpbXzMCbYOVka0ihpnnSgp8vhna76INETImhAx253vESFDjp7uQ6LnxRAa0YGsM4kmPlcAu2se000jFHzvns',
  // Public key for phone/browser push notifications (the private half lives only in Supabase secrets)
  VAPID_PUBLIC_KEY: 'BLp-Z815L4nxN7WfPTA300Au-P1p6ZSXLBOgqWIykc1ASAx9by1aTN43L1nP-EDGYb1R3vaHBW0uimW8oQUnDUw',
  SUPABASE_ANON_KEY:'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhwbnVqd2dremxtd3R4Z3ZheWV1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMxNTA4NjYsImV4cCI6MjEwODcyNjg2Nn0.uj9Z6YXiYh8EOLYhS1642dDBSRPPhRECF812Omz1-oU'
};
